from flask import Flask, render_template, request, jsonify
from flaskext.mysql import MySQL
import pymysql
import hashlib

app = Flask(__name__)
mysql = MySQL()

@app.route('/')
def home():
    return render_template('Admin.html')  


app.config['MYSQL_DATABASE_USER'] = 'root'
app.config['MYSQL_DATABASE_DB'] = 'bdgestus'
app.config['MYSQL_DATABASE_PASSWORD'] = 'Anyi#1530'
app.config['MYSQL_DATABASE_HOST'] = 'localhost'

mysql.init_app(app)

@app.route('/roles', methods=['POST'])
def crear_roles():
    nombre = request.form['nombre']
    conn = mysql.connect()
    cur = conn.cursor()
    cur.execute("INSERT INTO roles (nombre) VALUES (%s)", (nombre,))
    conn.commit()
    cur.close()
    conn.close()
    return "Rol creado correctamente"

@app.route('/usuarios', methods=['POST'])
def crear_usuarios():
    nombre = request.form['nombre_completo']
    correo = request.form['correo']
    usuario = request.form['usuario']
    contraseña = hashlib.sha256(request.form['contraseña'].encode()).hexdigest()
    estado = request.form['estado']
    rol_id = request.form['rol_id']
    conn = mysql.connect()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO usuarios (nombre_completo, correo, usuario, contraseña, estado, rol_id)
        VALUES (%s, %s, %s, %s, %s, %s)
    """, (nombre, correo, usuario, contraseña, estado, rol_id))
    conn.commit()
    cur.close()
    conn.close()
    return "Usuario creado correctamente"

@app.route('/solicitudes_recuperacion', methods=['POST'])
def crear_solicitudes():
    usuario_id = request.form['usuario_id']
    fecha = request.form['fecha_solicitud']
    estado = request.form['estado']
    conn = mysql.connect()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO solicitudes_recuperacion (usuario_id, fecha_solicitud, estado)
        VALUES (%s, %s, %s)
    """, (usuario_id, fecha, estado))
    conn.commit()
    cur.close()
    conn.close()
    return "Solicitud registrada"

@app.route('/empresas', methods=['POST'])
def crear_empresas():
    nombre = request.form['nombre']
    nit = request.form['nit']
    estado = request.form['estado']
    certificado = request.form['certificado_representacion']
    conn = mysql.connect()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO empresas (nombre, nit, estado, certificado_representacion)
        VALUES (%s, %s, %s, %s)
    """, (nombre, nit, estado, certificado))
    conn.commit()
    cur.close()
    conn.close()
    return "Empresa registrada correctamente"

@app.route('/formatos_globales', methods=['POST'])
def crear_formatos():
    nombre = request.form['nombre']
    descripcion = request.form['descripcion']
    archivo = request.form['archivo_url']
    fecha = request.form['fecha_creacion']
    conn = mysql.connect()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO formatos_globales (nombre, descripcion, archivo_url, fecha_creacion)
        VALUES (%s, %s, %s, %s)
    """, (nombre, descripcion, archivo, fecha))
    conn.commit()
    cur.close()
    conn.close()
    return "Formato registrado"

@app.route('/documentos_empresa', methods=['POST'])
def crear_documento_empresa():
    empresa_id = request.form['empresa_id']
    formato_id = request.form['formato_id']
    nombre = request.form['nombre']
    archivo = request.form['archivo_url']
    fecha = request.form['fecha_vencimiento']
    estado = request.form['estado']
    formato = request.form['formato']
    conn = mysql.connect()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO documentos_empresa (empresa_id, formato_id, nombre, archivo_url, fecha_vencimiento, estado, formato)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
    """, (empresa_id, formato_id, nombre, archivo, fecha, estado, formato))
    conn.commit()
    cur.close()
    conn.close()
    return "Documento agregado"

@app.route('/notificaciones', methods=['POST'])
def crear_notificaciones():
    documento_id = request.form['documento_id']
    fecha_envio = request.form['fecha_envio']
    dias_antes = request.form['dias_antes']
    enviada_a = request.form['enviada_a']
    conn = mysql.connect()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO notificaciones (documento_id, fecha_envio, dias_antes, enviada_a)
        VALUES (%s, %s, %s, %s)
    """, (documento_id, fecha_envio, dias_antes, enviada_a))
    conn.commit()
    cur.close()
    conn.close()
    return "Notificación creada"

@app.route('/roles_personal', methods=['POST'])
def crear_roles_personal():
    nombre = request.form['nombre']
    conn = mysql.connect()
    cur = conn.cursor()
    cur.execute("INSERT INTO roles_personal (nombre) VALUES (%s)", (nombre,))
    conn.commit()
    cur.close()
    conn.close()
    return "Rol personal creado"

@app.route('/personal', methods=['POST'])
def crear_personal():
    empresa_id = request.form['empresa_id']
    nombre = request.form['nombre_completo']
    documento = request.form['documento_identidad']
    correo = request.form['correo']
    cargo = request.form['cargo']
    conn = mysql.connect()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO personal (empresa_id, nombre_completo, documento_identidad, correo, cargo)
        VALUES (%s, %s, %s, %s, %s)
    """, (empresa_id, nombre, documento, correo, cargo))
    conn.commit()
    cur.close()
    conn.close()
    return "Personal registrado"

@app.route('/personal_rol', methods=['POST'])
def crear_personal_rol():
    personal_id = request.form['personal_id']
    rol_personal_id = request.form['rol_personal_id']
    conn = mysql.connect()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO personal_rol (personal_id, rol_personal_id)
        VALUES (%s, %s)
    """, (personal_id, rol_personal_id))
    conn.commit()
    cur.close()
    conn.close()
    return "Rol asignado al personal"

@app.route('/hallazgos', methods=['POST'])
def crear_hallazgos():
    empresa_id = request.form['empresa_id']
    descripcion = request.form['descripcion']
    tipo = request.form['tipo']
    fecha = request.form['fecha']
    conn = mysql.connect()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO hallazgos (empresa_id, descripcion, tipo, fecha)
        VALUES (%s, %s, %s, %s)
    """, (empresa_id, descripcion, tipo, fecha))
    conn.commit()
    cur.close()
    conn.close()
    return "Hallazgo registrado"

@app.route('/planes_accion', methods=['POST'])
def crear_planes_accion():
    hallazgo_id = request.form['hallazgo_id']
    tarea = request.form['tarea']
    responsable_id = request.form['responsable_id']
    fecha_limite = request.form['fecha_limite']
    estado = request.form['estado']
    conn = mysql.connect()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO planes_accion (hallazgo_id, tarea, responsable_id, fecha_limite, estado)
        VALUES (%s, %s, %s, %s, %s)
    """, (hallazgo_id, tarea, responsable_id, fecha_limite, estado))
    conn.commit()
    cur.close()
    conn.close()
    return "Plan de acción creado"

@app.route('/incidentes', methods=['POST'])
def crear_incidente():
    empresa_id = request.form['empresa_id']
    tipo = request.form['tipo']
    fecha = request.form['fecha']
    hora = request.form['hora']
    lugar = request.form['lugar']
    descripcion = request.form['descripcion']
    acciones = request.form['acciones_inmediatas']
    personas = request.form['personas_afectadas']
    conn = mysql.connect()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO incidentes (empresa_id, tipo, fecha, hora, lugar, descripcion, acciones_inmediatas, personas_afectadas)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
    """, (empresa_id, tipo, fecha, hora, lugar, descripcion, acciones, personas))
    conn.commit()
    cur.close()
    conn.close()
    return "Incidente registrado"

@app.route('/capacitaciones', methods=['POST'])
def crear_capacitacion():
    empresa_id = request.form['empresa_id']
    tema = request.form['tema']
    fecha = request.form['fecha']
    hora = request.form['hora']
    responsable_id = request.form['responsable_id']
    conn = mysql.connect()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO capacitaciones (empresa_id, tema, fecha, hora, responsable_id)
        VALUES (%s, %s, %s, %s, %s)
    """, (empresa_id, tema, fecha, hora, responsable_id))
    conn.commit()
    cur.close()
    conn.close()
    return "Capacitación registrada"

@app.route('/asistente_capacitacion', methods=['POST'])
def crear_asistente():
    capacitacion_id = request.form['capacitacion_id']
    personal_id = request.form['personal_id']
    conn = mysql.connect()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO asistente_capacitacion (capacitacion_id, personal_id)
        VALUES (%s, %s)
    """, (capacitacion_id, personal_id))
    conn.commit()
    cur.close()
    conn.close()
    return "Asistente registrado"

@app.route('/materiales_capacitacion', methods=['POST'])
def crear_material_capacitacion():
    capacitacion_id = request.form['capacitacion_id']
    archivo_url = request.form['archivo_url']
    descripcion = request.form['descripcion']
    conn = mysql.connect()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO materiales_capacitacion (capacitacion_id, archivo_url, descripcion)
        VALUES (%s, %s, %s)
    """, (capacitacion_id, archivo_url, descripcion))
    conn.commit()
    cur.close()
    conn.close()
    return "Material de capacitación registrado"

@app.route('/evaluaciones', methods=['POST'])
def crear_evaluacion():
    capacitacion_id = request.form['capacitacion_id']
    tipo = request.form['tipo']
    archivo_url = request.form['archivo_url']
    conn = mysql.connect()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO evaluaciones (capacitacion_id, tipo, archivo_url)
        VALUES (%s, %s, %s)
    """, (capacitacion_id, tipo, archivo_url))
    conn.commit()
    cur.close()
    conn.close()
    return "Evaluación registrada"

@app.route('/evaluaciones_medicas', methods=['POST'])
def crear_evaluacion_medica():
    personal_id = request.form['personal_id']
    fecha = request.form['fecha']
    archivo_url = request.form['archivo_url']
    restricciones = request.form['restricciones']
    observaciones = request.form['observaciones']
    recomendaciones = request.form['recomendaciones']
    conn = mysql.connect()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO evaluaciones_medicas (personal_id, fecha, archivo_url, restricciones, observaciones, recomendaciones)
        VALUES (%s, %s, %s, %s, %s, %s)
    """, (personal_id, fecha, archivo_url, restricciones, observaciones, recomendaciones))
    conn.commit()
    cur.close()
    conn.close()
    return "Evaluación médica registrada"

@app.route('/historial_cambios', methods=['POST'])
def crear_historial_cambios():
    usuario_id = request.form['usuario_id']
    entidad_afectada = request.form['entidad_afectada']
    id_entidad = request.form['id_entidad']
    tipo_accion = request.form['tipo_accion']
    descripcion = request.form['descripcion']
    conn = mysql.connect()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO historial_cambios (usuario_id, entidad_afectada, id_entidad, tipo_accion, descripcion)
        VALUES (%s, %s, %s, %s, %s)
    """, (usuario_id, entidad_afectada, id_entidad, tipo_accion, descripcion))
    conn.commit()
    cur.close()
    conn.close()
    return "Historial de cambio registrado"

@app.route('/normativas', methods=['POST'])
def crear_normativa():
    nombre = request.form['nombre']
    tipo = request.form['tipo']
    articulo = request.form['articulo']
    descripcion = request.form['descripcion']
    url = request.form['url_oficial']
    conn = mysql.connect()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO normativas (nombre, tipo, articulo, descripcion, url_oficial)
        VALUES (%s, %s, %s, %s, %s)
    """, (nombre, tipo, articulo, descripcion, url))
    conn.commit()
    cur.close()
    conn.close()
    return "Normativa registrada"

@app.route('/documentos_normativas', methods=['POST'])
def crear_documento_normativa():
    documento_id = request.form['documento_id']
    normativa_id = request.form['normativa_id']
    conn = mysql.connect()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO documentos_normativas (documento_id, normativa_id)
        VALUES (%s, %s)
    """, (documento_id, normativa_id))
    conn.commit()
    cur.close()
    conn.close()
    return "Relación documento-normativa registrada"

@app.route('/firmas_digitales', methods=['POST'])
def crear_firma_digital():
    documento_id = request.form['documento_id']
    usuario_id = request.form['usuario_id']
    hash_firma = request.form['hash_firma']
    certificado = request.form['certificado']
    conn = mysql.connect()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO firmas_digitales (documento_id, usuario_id, hash_firma, certificado)
        VALUES (%s, %s, %s, %s)
    """, (documento_id, usuario_id, hash_firma, certificado))
    conn.commit()
    cur.close()
    conn.close()
    return "Firma digital registrada"

@app.route('/peligros', methods=['POST'])
def crear_peligro():
    empresa_id = request.form['empresa_id']
    area_trabajo = request.form['area_trabajo']
    actividad = request.form['actividad']
    tipo_peligro = request.form['tipo_peligro']
    descripcion = request.form['descripcion']
    conn = mysql.connect()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO peligros (empresa_id, area_trabajo, actividad, tipo_peligro, descripcion)
        VALUES (%s, %s, %s, %s, %s)
    """, (empresa_id, area_trabajo, actividad, tipo_peligro, descripcion))
    conn.commit()
    cur.close()
    conn.close()
    return "Peligro registrado"

@app.route('/evaluaciones_riesgo', methods=['POST'])
def crear_evaluacion_riesgo():
    peligro_id = request.form['peligro_id']
    probabilidad = request.form['probabilidad']
    severidad = request.form['severidad']
    frecuencia = request.form['frecuencia']
    nivel_riesgo = request.form['nivel_riesgo']
    medidas_control = request.form['medidas_control']
    fecha_evaluacion = request.form['fecha_evaluacion']
    evaluado_por = request.form['evaluado_por']
    conn = mysql.connect()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO evaluaciones_riesgo (peligro_id, probabilidad, severidad, frecuencia, nivel_riesgo, medidas_control, fecha_evaluacion, evaluado_por)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
    """, (peligro_id, probabilidad, severidad, frecuencia, nivel_riesgo, medidas_control, fecha_evaluacion, evaluado_por))
    conn.commit()
    cur.close()
    conn.close()
    return "Evaluación de riesgo registrada"

@app.route('/epp', methods=['POST'])
def crear_epp():
    nombre = request.form['nombre']
    tipo = request.form['tipo_proteccion']
    normativa = request.form['normativa_cumplida']
    proveedor = request.form['proveedor']
    vida_util = request.form['vida_util_dias']
    vencimiento = request.form['fecha_vencimiento']
    conn = mysql.connect()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO epp (nombre, tipo_proteccion, normativa_cumplida, proveedor, vida_util_dias, fecha_vencimiento)
        VALUES (%s, %s, %s, %s, %s, %s)
    """, (nombre, tipo, normativa, proveedor, vida_util, vencimiento))
    conn.commit()
    cur.close()
    conn.close()
    return "Elemento de protección registrado"

@app.route('/epp_asignados', methods=['POST'])
def crear_epp_asignado():
    epp_id = request.form['epp_id']
    personal_id = request.form['personal_id']
    fecha = request.form['fecha_entrega']
    estado = request.form['estado']
    observaciones = request.form['observaciones']
    firmado = request.form['firmado']
    conn = mysql.connect()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO epp_asignados (epp_id, personal_id, fecha_entrega, estado, observaciones, firmado)
        VALUES (%s, %s, %s, %s, %s, %s)
    """, (epp_id, personal_id, fecha, estado, observaciones, firmado))
    conn.commit()
    cur.close()
    conn.close()
    return "EPP asignado correctamente"

if __name__ == '__main__':
    app.run(debug=True)
